<?php
$emailku = 'emailkalian@gmail.com'; // masukin email lu disini coeng -_-
?>